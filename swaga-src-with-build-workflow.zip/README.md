# SwagaBrowser

Исходный проект Android-браузера на Kotlin, Jetpack Compose и системном Android WebView.

## Сборка APK

Инструкция для получения APK через GitHub Actions находится в [BUILD_APK.md](BUILD_APK.md). Workflow автоматически собирает debug APK и публикует его в разделе Artifacts.

## Состояние проекта

Реализованы оболочка браузера, стартовая страница, адресная строка, выбор поисковой системы, вкладки, недавние сайты и темы. Полный список готовых и запланированных функций приведён в [docs/SWAGA_README.md](docs/SWAGA_README.md).
