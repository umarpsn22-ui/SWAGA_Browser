package app.swaga.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.swaga.browser.BrowserViewModel
import app.swaga.browser.themes.LocalSwaga
import app.swaga.browser.themes.panel

private data class QuickLink(val title: String, val url: String)

private val quickLinks = listOf(
    QuickLink("Википедия", "https://ru.wikipedia.org"),
    QuickLink("YouTube", "https://www.youtube.com"),
    QuickLink("GitHub", "https://github.com"),
    QuickLink("Telegram", "https://web.telegram.org"),
    QuickLink("VK", "https://vk.com"),
    QuickLink("Хабр", "https://habr.com"),
    QuickLink("Reddit", "https://www.reddit.com"),
    QuickLink("OpenStreetMap", "https://www.openstreetmap.org"),
)

@Composable
fun StartPage(
    vm: BrowserViewModel,
    onEngines: () -> Unit,
    onSettings: () -> Unit,
) {
    val c = LocalSwaga.current
    val focusManager = LocalFocusManager.current
    var query by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(80.dp))
            Text(
                "#SWAGA",
                color = c.text,
                fontSize = 46.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-1.5).sp,
            )
            Spacer(Modifier.height(28.dp))

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .panel(RoundedCornerShape(26.dp), elevated = true)
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                EngineBadge(vm.engine, 32.dp, Modifier.clickable { onEngines() })
                Spacer(Modifier.width(12.dp))
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = c.text, fontSize = 16.sp),
                    cursorBrush = SolidColor(c.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search, keyboardType = KeyboardType.Uri),
                    keyboardActions = KeyboardActions(onSearch = {
                        vm.submit(query)
                        query = ""
                        focusManager.clearFocus()
                    }),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isEmpty()) Text("Поиск или адрес", color = c.dim, fontSize = 16.sp)
                            inner()
                        }
                    },
                )
                IconButton(
                    onClick = {
                        vm.submit(query)
                        query = ""
                        focusManager.clearFocus()
                    },
                    modifier = Modifier.size(36.dp),
                ) {
                    Icon(Icons.Filled.Search, contentDescription = "Искать")
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Ищем в ${vm.engine.name}",
                color = c.dim,
                fontSize = 13.sp,
                modifier = Modifier.clickable { onEngines() },
            )

            Spacer(Modifier.height(32.dp))
            SectionTitle("Быстрые ссылки")
            quickLinks.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { link ->
                        Tile(link.title, link.url, Modifier.weight(1f)) { vm.submit(link.url) }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            if (vm.recent.isNotEmpty()) {
                Spacer(Modifier.height(32.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Недавние", color = c.dim, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.clearRecent() }) { Text("Очистить", color = c.dim, fontSize = 13.sp) }
                }
                vm.recent.forEach { site ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { vm.submit(site.url) }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Letter(hostOf(site.url), 34.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(site.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
                            Text(hostOf(site.url), color = c.dim, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
        }

        IconButton(
            onClick = onSettings,
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
        ) {
            Icon(Icons.Filled.Settings, contentDescription = "Настройки")
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    val c = LocalSwaga.current
    Row(Modifier.fillMaxWidth()) {
        Text(text, color = c.dim, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Tile(title: String, url: String, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalSwaga.current
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Letter(title, 52.dp)
        Spacer(Modifier.height(6.dp))
        Text(
            title,
            color = c.text,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun Letter(label: String, size: androidx.compose.ui.unit.Dp) {
    val c = LocalSwaga.current
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(c.surfaceHigh),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label.take(1).uppercase(),
            color = c.text,
            fontSize = (size.value * 0.42f).sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
