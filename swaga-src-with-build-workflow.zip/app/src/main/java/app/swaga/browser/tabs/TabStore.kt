package app.swaga.browser.tabs

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Сохраняет список вкладок (адрес и заголовок) между запусками. */
class TabStore(private val prefs: SharedPreferences) {

    fun save(tabs: List<TabSnapshot>, activeIndex: Int) {
        val arr = JSONArray()
        tabs.forEach {
            arr.put(
                JSONObject()
                    .put("u", it.url ?: JSONObject.NULL)
                    .put("t", it.title),
            )
        }
        prefs.edit().putString(KEY_TABS, arr.toString()).putInt(KEY_ACTIVE, activeIndex).apply()
    }

    fun load(): Pair<List<TabSnapshot>, Int> {
        val raw = prefs.getString(KEY_TABS, null) ?: return emptyList<TabSnapshot>() to 0
        return try {
            val arr = JSONArray(raw)
            val list = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                TabSnapshot(if (o.isNull("u")) null else o.getString("u"), o.optString("t", ""))
            }
            list to prefs.getInt(KEY_ACTIVE, 0)
        } catch (e: Exception) {
            emptyList<TabSnapshot>() to 0
        }
    }

    private companion object {
        const val KEY_TABS = "tabs_json"
        const val KEY_ACTIVE = "tabs_active"
    }
}
