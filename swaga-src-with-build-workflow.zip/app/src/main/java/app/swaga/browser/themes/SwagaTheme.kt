package app.swaga.browser.themes

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.core.view.WindowCompat

enum class ThemeId(val title: String) {
    DARK("Тёмная"),
    MIDNIGHT("Полночь"),
    LIGHT("Светлая"),
}

enum class MaterialId(val title: String) {
    GLASS("Стекло"),
    MATTE("Матовый"),
}

val AccentChoices = listOf(
    Color(0xFF6C9CFF),
    Color(0xFF5FD1C4),
    Color(0xFFB98CFF),
    Color(0xFFFF8A7A),
    Color(0xFFE6C15A),
)

@Immutable
class SwagaColors(
    val bg: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val text: Color,
    val dim: Color,
    val outline: Color,
    val accent: Color,
    val onAccent: Color,
    val isDark: Boolean,
    val glass: Boolean,
)

val LocalSwaga = staticCompositionLocalOf<SwagaColors> { error("SwagaTheme is missing") }

fun swagaColors(theme: ThemeId, material: MaterialId, accentIndex: Int): SwagaColors {
    val base = AccentChoices[accentIndex.coerceIn(0, AccentChoices.lastIndex)]
    val glass = material == MaterialId.GLASS
    return when (theme) {
        ThemeId.MIDNIGHT -> build(
            bg = Color(0xFF0A1224), surface = Color(0xFF111C36), high = Color(0xFF18264A),
            text = Color(0xFFE8EEFF), dim = Color(0xFF8D9BBF), outline = Color(0xFF2A3A66),
            accent = base, dark = true, glass = glass,
        )
        ThemeId.DARK -> build(
            bg = Color(0xFF0E0E10), surface = Color(0xFF17171A), high = Color(0xFF212126),
            text = Color(0xFFECECF0), dim = Color(0xFF9A9AA5), outline = Color(0xFF2C2C33),
            accent = base, dark = true, glass = glass,
        )
        ThemeId.LIGHT -> build(
            bg = Color(0xFFF4F6FA), surface = Color(0xFFFFFFFF), high = Color(0xFFE9EDF5),
            text = Color(0xFF0F1730), dim = Color(0xFF5B6685), outline = Color(0xFFD5DBE8),
            accent = lerp(base, Color.Black, 0.3f), dark = false, glass = glass,
        )
    }
}

private fun build(
    bg: Color, surface: Color, high: Color, text: Color, dim: Color, outline: Color,
    accent: Color, dark: Boolean, glass: Boolean,
) = SwagaColors(
    bg = bg, surface = surface, surfaceHigh = high, text = text, dim = dim, outline = outline,
    accent = accent,
    onAccent = if (accent.luminance() > 0.5f) Color(0xFF0A1224) else Color.White,
    isDark = dark, glass = glass,
)

@Composable
fun SwagaTheme(
    theme: ThemeId,
    material: MaterialId,
    accentIndex: Int,
    content: @Composable () -> Unit,
) {
    val c = swagaColors(theme, material, accentIndex)
    val scheme = if (c.isDark) {
        darkColorScheme(
            primary = c.accent, onPrimary = c.onAccent,
            background = c.bg, onBackground = c.text,
            surface = c.surface, onSurface = c.text,
            surfaceVariant = c.surfaceHigh, onSurfaceVariant = c.dim,
            outline = c.outline,
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = c.onAccent,
            background = c.bg, onBackground = c.text,
            surface = c.surface, onSurface = c.text,
            surfaceVariant = c.surfaceHigh, onSurfaceVariant = c.dim,
            outline = c.outline,
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val ctrl = WindowCompat.getInsetsController(window, view)
                ctrl.isAppearanceLightStatusBars = !c.isDark
                ctrl.isAppearanceLightNavigationBars = !c.isDark
            }
        }
    }

    CompositionLocalProvider(LocalSwaga provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/**
 * Поверхность панели. Glass: полупрозрачная заливка и тонкая граница.
 * Matte: непрозрачная заливка и сдержанная тень.
 */
@Composable
fun Modifier.panel(
    shape: Shape = RoundedCornerShape(16.dp),
    elevated: Boolean = false,
): Modifier {
    val c = LocalSwaga.current
    val base = if (elevated) c.surfaceHigh else c.surface
    return if (c.glass) {
        this
            .background(base.copy(alpha = 0.72f), shape)
            .border(1.dp, c.outline.copy(alpha = 0.85f), shape)
    } else {
        this
            .shadow(3.dp, shape, clip = false)
            .background(base, shape)
    }
}
