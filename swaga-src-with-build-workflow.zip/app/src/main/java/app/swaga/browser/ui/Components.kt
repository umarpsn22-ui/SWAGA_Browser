package app.swaga.browser.ui

import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.swaga.browser.search.SearchEngine
import app.swaga.browser.themes.LocalSwaga

fun hostOf(url: String?): String {
    if (url.isNullOrBlank()) return ""
    return Uri.parse(url).host?.removePrefix("www.") ?: url
}

@Composable
fun EngineBadge(engine: SearchEngine, size: Dp = 28.dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(engine.brand)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            engine.monogram,
            color = Color.White,
            fontSize = (size.value * 0.46f).sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
fun TabsCountIcon(count: Int) {
    val c = LocalSwaga.current
    Box(
        modifier = Modifier
            .size(26.dp)
            .border(BorderStroke(1.6.dp, c.text), RoundedCornerShape(7.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            if (count > 99) "99+" else count.toString(),
            color = c.text,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
