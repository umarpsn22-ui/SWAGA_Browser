package app.swaga.browser

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import app.swaga.browser.history.RecentSite
import app.swaga.browser.history.RecentStore
import app.swaga.browser.search.SearchEngine
import app.swaga.browser.search.SearchEngines
import app.swaga.browser.search.UrlResolver
import app.swaga.browser.tabs.Tab
import app.swaga.browser.tabs.TabSnapshot
import app.swaga.browser.tabs.TabStore
import app.swaga.browser.themes.MaterialId
import app.swaga.browser.themes.ThemeId

class BrowserViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("swaga", Context.MODE_PRIVATE)
    private val tabStore = TabStore(prefs)
    private val recentStore = RecentStore(prefs)

    var themeId by mutableStateOf(ThemeId.MIDNIGHT)
        private set
    var materialId by mutableStateOf(MaterialId.GLASS)
        private set
    var accentIndex by mutableIntStateOf(0)
        private set
    var engineId by mutableStateOf("ddg")
        private set
    var customEngine by mutableStateOf<SearchEngine?>(null)
        private set

    /** Одноразовое сообщение для Snackbar. */
    var message by mutableStateOf<String?>(null)

    val tabs = mutableStateListOf<Tab>()
    var activeTabId by mutableLongStateOf(-1L)
        private set
    val closedTabs = mutableStateListOf<TabSnapshot>()
    val recent = mutableStateListOf<RecentSite>()

    private var nextId = 1L

    val activeTab: Tab? get() = tabs.firstOrNull { it.id == activeTabId }
    val engines: List<SearchEngine> get() = SearchEngines.builtIn + listOfNotNull(customEngine)
    val engine: SearchEngine get() = engines.firstOrNull { it.id == engineId } ?: SearchEngines.builtIn.first { it.id == "ddg" }

    init {
        themeId = runCatching { ThemeId.valueOf(prefs.getString("theme", "") ?: "") }.getOrDefault(ThemeId.MIDNIGHT)
        materialId = runCatching { MaterialId.valueOf(prefs.getString("material", "") ?: "") }.getOrDefault(MaterialId.GLASS)
        accentIndex = prefs.getInt("accent", 0)
        engineId = prefs.getString("engine", "ddg") ?: "ddg"
        val tpl = prefs.getString("custom_tpl", null)
        if (tpl != null && SearchEngines.validateTemplate(tpl) == null) {
            customEngine = SearchEngines.custom(prefs.getString("custom_name", "") ?: "", tpl)
        }
        recent.addAll(recentStore.load())

        val (snaps, active) = tabStore.load()
        if (snaps.isEmpty()) {
            newTab()
        } else {
            snaps.forEach { tabs.add(createTab(it.url, it.title)) }
            activeTabId = tabs[active.coerceIn(0, tabs.lastIndex)].id
        }
    }

    // ---- Настройки ----

    fun setTheme(t: ThemeId) { themeId = t; prefs.edit().putString("theme", t.name).apply() }
    fun setMaterial(m: MaterialId) { materialId = m; prefs.edit().putString("material", m.name).apply() }
    fun setAccent(i: Int) { accentIndex = i; prefs.edit().putInt("accent", i).apply() }

    fun selectEngine(id: String) {
        if (engines.none { it.id == id }) return
        engineId = id
        prefs.edit().putString("engine", id).apply()
    }

    /** Возвращает текст ошибки или null, если сохранено. */
    fun saveCustomEngine(name: String, template: String): String? {
        SearchEngines.validateTemplate(template)?.let { return it }
        customEngine = SearchEngines.custom(name, template)
        prefs.edit().putString("custom_name", name.trim()).putString("custom_tpl", template.trim()).apply()
        selectEngine("custom")
        return null
    }

    fun clearRecent() {
        recentStore.clear()
        recent.clear()
    }

    // ---- Вкладки ----

    private fun createTab(url: String?, title: String): Tab =
        Tab(nextId++, url, title).also { tab ->
            tab.onPageLoaded = { t ->
                val u = t.url
                if (u != null) {
                    val next = recentStore.add(recent.toList(), t.title, u)
                    recent.clear()
                    recent.addAll(next)
                }
            }
        }

    fun newTab(url: String? = null, select: Boolean = true): Tab {
        val tab = createTab(url, "")
        if (url != null) tab.navRequest = app.swaga.browser.tabs.NavRequest(url)
        tabs.add(tab)
        if (select) activeTabId = tab.id
        return tab
    }

    fun selectTab(tab: Tab) { activeTabId = tab.id }

    fun closeTab(tab: Tab) {
        val index = tabs.indexOf(tab)
        if (index < 0) return
        if (tab.url != null) {
            closedTabs.add(tab.snapshot())
            if (closedTabs.size > 10) closedTabs.removeAt(0)
        }
        tabs.removeAt(index)
        if (tabs.isEmpty()) {
            newTab()
        } else if (tab.id == activeTabId) {
            activeTabId = tabs[index.coerceAtMost(tabs.lastIndex)].id
        }
    }

    fun restoreClosedTab() {
        if (closedTabs.isEmpty()) return
        val snap = closedTabs.removeAt(closedTabs.lastIndex)
        newTab(snap.url)
    }

    fun closeToStart(tab: Tab) = tab.resetToStart()

    // ---- Навигация ----

    fun submit(raw: String) {
        val tab = activeTab ?: newTab()
        when (val r = UrlResolver.resolve(raw, engine)) {
            is UrlResolver.Resolved.Open -> tab.load(r.url)
            is UrlResolver.Resolved.Rejected -> message = r.reason
            UrlResolver.Resolved.Empty -> Unit
        }
    }

    /** Ссылка из другого приложения: открываем только http/https в новой вкладке. */
    fun openExternal(url: String) {
        val r = UrlResolver.resolve(url, engine)
        if (r is UrlResolver.Resolved.Open && !r.isSearch) newTab(r.url)
    }

    fun persist() {
        val list = tabs.map { it.snapshot() }
        val activeIndex = tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0)
        tabStore.save(list, activeIndex)
    }
}
