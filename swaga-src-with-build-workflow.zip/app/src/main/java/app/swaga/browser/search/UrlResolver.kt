package app.swaga.browser.search

import android.net.Uri

/**
 * Решает, что ввёл пользователь: адрес сайта или поисковый запрос.
 * Опасные схемы (javascript:, file:, intent: и т.п.) отклоняются.
 */
object UrlResolver {

    sealed interface Resolved {
        data class Open(val url: String, val isSearch: Boolean) : Resolved
        data class Rejected(val reason: String) : Resolved
        data object Empty : Resolved
    }

    private val blockedSchemes = setOf(
        "javascript", "data", "file", "content", "intent", "blob",
        "vbscript", "about", "chrome", "view-source",
    )

    private val hostPattern = Regex(
        "^(localhost|(\\d{1,3}\\.){3}\\d{1,3}|([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,})(:\\d{1,5})?([/?#].*)?$",
    )

    fun resolve(raw: String, engine: SearchEngine): Resolved {
        val s = raw.trim()
        if (s.isEmpty()) return Resolved.Empty

        if (s.any { it.isWhitespace() }) return search(s, engine)

        val schemeSep = s.indexOf("://")
        if (schemeSep > 0) {
            val scheme = s.substring(0, schemeSep).lowercase()
            return if (scheme == "http" || scheme == "https") {
                if (Uri.parse(s).host.isNullOrBlank()) Resolved.Rejected("Некорректный адрес.")
                else Resolved.Open(s, false)
            } else {
                Resolved.Rejected("Схема «$scheme» не поддерживается.")
            }
        }

        if (hostPattern.matches(s)) {
            val local = s.startsWith("localhost") || s.first().isDigit() && s.count { it == '.' } == 3
            return Resolved.Open((if (local) "http://" else "https://") + s, false)
        }

        val colon = s.indexOf(':')
        if (colon > 0 && s.substring(0, colon).lowercase() in blockedSchemes) {
            return Resolved.Rejected("Эта схема адреса заблокирована из соображений безопасности.")
        }

        return search(s, engine)
    }

    private fun search(query: String, engine: SearchEngine): Resolved =
        Resolved.Open(engine.searchUrl(query), true)
}
