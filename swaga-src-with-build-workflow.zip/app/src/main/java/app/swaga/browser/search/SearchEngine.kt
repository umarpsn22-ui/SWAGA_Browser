package app.swaga.browser.search

import android.net.Uri

enum class PrivacyLevel(val label: String) {
    LOW("Низкая"),
    MEDIUM("Средняя"),
    HIGH("Выше средней"),
}

/**
 * Поисковая система — отдельный компонент: браузер лишь подставляет запрос
 * в [searchTemplate] и открывает результат в своей вкладке.
 * Логотипы пока заменены монограммами: официальные логотипы — товарные знаки.
 */
data class SearchEngine(
    val id: String,
    val name: String,
    val monogram: String,
    val brand: Long,
    val description: String,
    val bestFor: String,
    val privacy: PrivacyLevel,
    val privacyNote: String,
    val searchTemplate: String,
    val isCustom: Boolean = false,
) {
    fun searchUrl(query: String): String = searchTemplate.replace("%s", Uri.encode(query))
}

object SearchEngines {
    val builtIn: List<SearchEngine> = listOf(
        SearchEngine(
            "google", "Google", "G", 0xFF4285F4,
            "Самый большой индекс и сильное ранжирование.",
            "Сложные запросы, локальный поиск, новости.",
            PrivacyLevel.LOW,
            "Запросы могут связываться с аккаунтом Google и рекламным профилем, если вы вошли в него.",
            "https://www.google.com/search?q=%s",
        ),
        SearchEngine(
            "bing", "Bing", "B", 0xFF0F8A8A,
            "Поиск Microsoft, его результаты используют и другие сервисы.",
            "Общие запросы, изображения, видео.",
            PrivacyLevel.LOW,
            "Часть экосистемы Microsoft с рекламой; данные могут использоваться для персонализации.",
            "https://www.bing.com/search?q=%s",
        ),
        SearchEngine(
            "ddg", "DuckDuckGo", "D", 0xFFDE5833,
            "Поиск с упором на приватность; часть результатов берёт у Bing.",
            "Повседневный поиск без персонального профиля.",
            PrivacyLevel.HIGH,
            "Компания заявляет, что не строит профили пользователей. Это её заявление, не независимый аудит.",
            "https://duckduckgo.com/?q=%s",
        ),
        SearchEngine(
            "brave", "Brave Search", "Br", 0xFFFB542B,
            "Собственный независимый индекс.",
            "Альтернатива Google/Bing, технические запросы.",
            PrivacyLevel.HIGH,
            "Заявляет об отсутствии профилирования. Индекс покрывает меньше редких запросов.",
            "https://search.brave.com/search?q=%s",
        ),
        SearchEngine(
            "startpage", "Startpage", "S", 0xFF3B6EF5,
            "Показывает результаты Google, пропуская запросы через свой сервер.",
            "Качество Google с меньшей привязкой к вам.",
            PrivacyLevel.HIGH,
            "Скрывает ваш IP и профиль от Google. Владелец — рекламная группа, часть пользователей это учитывает.",
            "https://www.startpage.com/sp/search?query=%s",
        ),
        SearchEngine(
            "qwant", "Qwant", "Q", 0xFF5C6BC0,
            "Европейский поиск (Франция), работает по правилам GDPR.",
            "Пользователи, которым важна европейская юрисдикция.",
            PrivacyLevel.MEDIUM,
            "Не продаёт персональные данные по заявлению компании; часть результатов приходит от Bing.",
            "https://www.qwant.com/?q=%s",
        ),
        SearchEngine(
            "ecosia", "Ecosia", "E", 0xFF2E8B57,
            "Поиск, направляющий часть прибыли на посадку деревьев.",
            "Обычный поиск с экологической целью.",
            PrivacyLevel.MEDIUM,
            "Собирает ограниченные данные; результаты в основном приходят от крупных поисковиков.",
            "https://www.ecosia.org/search?q=%s",
        ),
        SearchEngine(
            "yahoo", "Yahoo", "Y", 0xFF6001D2,
            "Классический портал, результаты строятся на Bing.",
            "Новости и привычный интерфейс.",
            PrivacyLevel.LOW,
            "Рекламная экосистема с персонализацией.",
            "https://search.yahoo.com/search?p=%s",
        ),
    )

    const val PRIVACY_DISCLAIMER =
        "Оценка приватности — наш вывод из публичных политик компаний, а не независимый аудит. Условия меняются: проверяйте актуальные."

    /** null — шаблон корректен, иначе текст ошибки. */
    fun validateTemplate(raw: String): String? {
        val t = raw.trim()
        if (!t.contains("%s")) return "Вставьте %s туда, куда подставлять запрос."
        if (!(t.startsWith("https://") || t.startsWith("http://"))) return "Адрес должен начинаться с https://"
        val host = Uri.parse(t.replace("%s", "x")).host
        if (host.isNullOrBlank()) return "Не удалось определить сайт в адресе."
        return null
    }

    fun custom(name: String, template: String): SearchEngine {
        val clean = name.trim().ifEmpty { Uri.parse(template.replace("%s", "x")).host.orEmpty() }
        return SearchEngine(
            id = "custom",
            name = clean,
            monogram = clean.take(1).uppercase().ifEmpty { "?" },
            brand = 0xFF607D8B,
            description = "Ваш поисковик по шаблону адреса.",
            bestFor = "Свои сервисы и сайты с поиском.",
            privacy = PrivacyLevel.MEDIUM,
            privacyNote = "Приватность зависит от выбранного сервиса; браузер её не оценивает.",
            searchTemplate = template.trim(),
            isCustom = true,
        )
    }
}
