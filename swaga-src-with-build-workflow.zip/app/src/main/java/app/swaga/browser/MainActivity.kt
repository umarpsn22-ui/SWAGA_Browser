package app.swaga.browser

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import app.swaga.browser.themes.SwagaTheme
import app.swaga.browser.ui.BrowserApp

class MainActivity : ComponentActivity() {

    private val vm: BrowserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            SwagaTheme(vm.themeId, vm.materialId, vm.accentIndex) {
                BrowserApp(vm)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onStop() {
        vm.persist()
        super.onStop()
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_VIEW) {
            i.dataString?.let { vm.openExternal(it) }
        }
    }
}
