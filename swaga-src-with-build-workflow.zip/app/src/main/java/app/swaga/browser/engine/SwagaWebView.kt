package app.swaga.browser.engine

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import app.swaga.browser.tabs.Tab

/** Создание и уничтожение WebView — единственное место, где мы трогаем движок. */
object SwagaWebView {

    @SuppressLint("SetJavaScriptEnabled")
    fun create(context: Context, tab: Tab): WebView {
        val wv = WebView(context)
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true
            setGeolocationEnabled(false)
        }
        wv.webViewClient = client(tab)
        wv.webChromeClient = chrome(tab)
        tab.webView = wv

        val saved = tab.savedState
        if (saved != null) {
            wv.restoreState(saved)
            tab.savedState = null
        } else {
            val req = tab.navRequest?.takeIf { !it.handled }
            val target = req?.url ?: tab.url
            req?.handled = true
            if (target != null) wv.loadUrl(target)
        }
        return wv
    }

    /** Применяет новый запрос навигации к уже созданному WebView. */
    fun consume(wv: WebView, tab: Tab) {
        val req = tab.navRequest
        if (req != null && !req.handled) {
            req.handled = true
            wv.loadUrl(req.url)
        }
    }

    fun release(wv: WebView, tab: Tab) {
        if (tab.url != null) {
            val b = Bundle()
            wv.saveState(b)
            tab.savedState = b
        }
        wv.stopLoading()
        wv.setWebChromeClient(null)
        wv.webViewClient = WebViewClient()
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.destroy()
        if (tab.webView === wv) tab.webView = null
    }

    private fun sync(view: WebView?, tab: Tab) {
        if (view == null) return
        tab.canGoBack = view.canGoBack()
        tab.canGoForward = view.canGoForward()
    }

    private fun client(tab: Tab) = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val uri = request?.url ?: return true
            return when (uri.scheme?.lowercase()) {
                "http", "https" -> false
                "mailto", "tel" -> {
                    view?.context?.let { openExternal(it, uri) }
                    true
                }
                else -> true // intent:, file:, javascript: и прочее блокируем
            }
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            tab.loading = true
            tab.error = null
            if (!url.isNullOrBlank() && !url.startsWith("about:")) tab.url = url
            sync(view, tab)
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            tab.loading = false
            if (!url.isNullOrBlank() && !url.startsWith("about:")) tab.url = url
            sync(view, tab)
            if (tab.error == null) tab.onPageLoaded?.invoke(tab)
        }

        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
            if (!url.isNullOrBlank() && !url.startsWith("about:")) tab.url = url
            sync(view, tab)
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?,
        ) {
            if (request?.isForMainFrame == true) {
                tab.error = error?.description?.toString() ?: "Неизвестная ошибка"
            }
        }
    }

    // Разрешения сайтов (камера, микрофон, геолокация) по умолчанию отклоняются:
    // WebChromeClient без переопределений их не выдаёт. Управление — этап 7.
    private fun chrome(tab: Tab) = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            tab.progress = newProgress
            tab.loading = newProgress < 100
        }

        override fun onReceivedTitle(view: WebView?, title: String?) {
            if (!title.isNullOrBlank()) tab.title = title
        }
    }

    private fun openExternal(context: Context, uri: Uri) {
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: ActivityNotFoundException) {
        }
    }
}
