package app.swaga.browser.ui

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.swaga.browser.BrowserViewModel
import app.swaga.browser.tabs.Tab
import app.swaga.browser.themes.LocalSwaga
import app.swaga.browser.themes.panel

@Composable
fun BottomBar(
    vm: BrowserViewModel,
    tab: Tab?,
    onTabs: () -> Unit,
    onSettings: () -> Unit,
    onEngines: () -> Unit,
) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val onPage = tab != null && tab.url != null

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        if (tab != null && onPage) {
            IconButton(onClick = {
                if (tab.canGoBack) tab.webView?.goBack() else vm.closeToStart(tab)
            }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
            }
            key(tab.id) {
                AddressPill(vm = vm, tab = tab, onEngines = onEngines, modifier = Modifier.weight(1f))
            }
        } else {
            Spacer(Modifier.weight(1f))
        }

        IconButton(onClick = onTabs) { TabsCountIcon(vm.tabs.size) }

        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Меню")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Новая вкладка") },
                    onClick = { menu = false; vm.newTab() },
                )
                DropdownMenuItem(
                    text = { Text("Вперёд") },
                    enabled = tab?.canGoForward == true,
                    onClick = { menu = false; tab?.webView?.goForward() },
                )
                DropdownMenuItem(
                    text = { Text(if (tab?.loading == true) "Остановить" else "Обновить") },
                    enabled = onPage,
                    onClick = {
                        menu = false
                        if (tab?.loading == true) tab?.webView?.stopLoading() else tab?.webView?.reload()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Поделиться ссылкой") },
                    enabled = onPage,
                    onClick = {
                        menu = false
                        val url = tab?.url
                        if (url != null) {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, url)
                            }
                            ctx.startActivity(Intent.createChooser(send, null))
                        }
                    },
                )
                DropdownMenuItem(
                    text = { Text("Настройки") },
                    onClick = { menu = false; onSettings() },
                )
            }
        }
    }
}

@Composable
fun AddressPill(
    vm: BrowserViewModel,
    tab: Tab,
    onEngines: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = LocalSwaga.current
    val focusManager = LocalFocusManager.current
    var focused by remember { mutableStateOf(false) }
    var field by remember { mutableStateOf(TextFieldValue(hostOf(tab.url))) }

    LaunchedEffect(tab.url, focused) {
        if (!focused) field = TextFieldValue(hostOf(tab.url))
    }

    Row(
        modifier
            .height(44.dp)
            .panel(RoundedCornerShape(22.dp))
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        EngineBadge(vm.engine, 28.dp, Modifier.clickable { onEngines() })
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = field,
            onValueChange = { field = it },
            singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 15.sp),
            cursorBrush = SolidColor(c.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
            keyboardActions = KeyboardActions(onGo = {
                vm.submit(field.text)
                focusManager.clearFocus()
            }),
            modifier = Modifier
                .weight(1f)
                .onFocusChanged { st ->
                    if (st.isFocused) {
                        if (!focused) {
                            focused = true
                            val u = tab.url.orEmpty()
                            field = TextFieldValue(u, TextRange(0, u.length))
                        }
                    } else {
                        focused = false
                    }
                },
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (field.text.isEmpty()) {
                        Text("Поиск или адрес", color = c.dim, fontSize = 15.sp)
                    }
                    inner()
                }
            },
        )
        if (!focused) {
            val https = tab.url?.startsWith("https://") == true
            Icon(
                imageVector = if (https) Icons.Filled.Lock else Icons.Filled.Warning,
                contentDescription = if (https) "Соединение по HTTPS" else "Соединение без шифрования",
                tint = if (https) c.dim else Color(0xFFE6A23C),
                modifier = Modifier.padding(end = 6.dp).size(16.dp),
            )
        }
    }
}
