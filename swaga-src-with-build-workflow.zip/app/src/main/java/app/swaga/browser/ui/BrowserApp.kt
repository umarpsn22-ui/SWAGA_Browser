package app.swaga.browser.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.swaga.browser.BrowserViewModel
import app.swaga.browser.engine.WebViewHost
import app.swaga.browser.tabs.Tab
import app.swaga.browser.themes.LocalSwaga

@Composable
fun BrowserApp(vm: BrowserViewModel) {
    val c = LocalSwaga.current
    val tab = vm.activeTab
    var showSwitcher by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showEngines by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            snackbar.showSnackbar(m)
            vm.message = null
        }
    }

    BackHandler(enabled = showSwitcher) { showSwitcher = false }
    BackHandler(enabled = !showSwitcher && tab != null && tab.url != null) {
        if (tab != null) {
            if (tab.canGoBack) tab.webView?.goBack() else vm.closeToStart(tab)
        }
    }

    CompositionLocalProvider(LocalContentColor provides c.text) {
        Box(
            Modifier
                .fillMaxSize()
                .background(c.bg)
                .systemBarsPadding()
                .imePadding(),
        ) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when {
                        tab == null -> Unit
                        tab.url == null -> StartPage(
                            vm = vm,
                            onEngines = { showEngines = true },
                            onSettings = { showSettings = true },
                        )
                        else -> key(tab.id) { BrowserPage(tab) }
                    }
                }
                BottomBar(
                    vm = vm,
                    tab = tab,
                    onTabs = { showSwitcher = true },
                    onSettings = { showSettings = true },
                    onEngines = { showEngines = true },
                )
            }

            if (showSwitcher) {
                TabSwitcher(vm = vm, onClose = { showSwitcher = false })
            }

            SnackbarHost(
                snackbar,
                Modifier.align(Alignment.BottomCenter).padding(bottom = 72.dp),
            )
        }

        if (showSettings) {
            SettingsSheet(
                vm = vm,
                onDismiss = { showSettings = false },
                onEngines = { showSettings = false; showEngines = true },
            )
        }
        if (showEngines) {
            EngineSheet(vm = vm, onDismiss = { showEngines = false })
        }
    }
}

@Composable
private fun BrowserPage(tab: Tab) {
    val c = LocalSwaga.current
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().height(2.dp)) {
            if (tab.loading) {
                LinearProgressIndicator(
                    progress = { tab.progress / 100f },
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = c.accent,
                    trackColor = Color.Transparent,
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            WebViewHost(tab)
            val err = tab.error
            if (err != null) {
                ErrorOverlay(err) {
                    tab.error = null
                    tab.webView?.reload()
                }
            }
        }
    }
}

@Composable
private fun ErrorOverlay(message: String, onRetry: () -> Unit) {
    val c = LocalSwaga.current
    Box(Modifier.fillMaxSize().background(c.bg), contentAlignment = Alignment.Center) {
        Column(
            Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = c.dim, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(16.dp))
            Text("Страница не открылась", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text(message, color = c.dim, fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
            ) { Text("Повторить") }
        }
    }
}
