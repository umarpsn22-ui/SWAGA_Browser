package app.swaga.browser.history

import android.content.SharedPreferences
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class RecentSite(val title: String, val url: String)

/** Недавно посещённые сайты для стартовой страницы (по одному на домен). Полная история — этап 4. */
class RecentStore(private val prefs: SharedPreferences) {

    fun load(): List<RecentSite> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                RecentSite(o.optString("t"), o.getString("u"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(current: List<RecentSite>, title: String, url: String): List<RecentSite> {
        val uri = Uri.parse(url)
        val host = uri.host ?: return current
        if (uri.scheme != "http" && uri.scheme != "https") return current
        val next = (listOf(RecentSite(title.ifBlank { host }, url)) +
            current.filter { Uri.parse(it.url).host != host }).take(MAX)
        save(next)
        return next
    }

    fun clear() = prefs.edit().remove(KEY).apply()

    private fun save(list: List<RecentSite>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private companion object {
        const val KEY = "recent_json"
        const val MAX = 8
    }
}
