package app.swaga.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.swaga.browser.BrowserViewModel
import app.swaga.browser.tabs.Tab
import app.swaga.browser.themes.LocalSwaga
import app.swaga.browser.themes.panel

@Composable
fun TabSwitcher(vm: BrowserViewModel, onClose: () -> Unit) {
    val c = LocalSwaga.current
    Column(Modifier.fillMaxSize().background(c.bg)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Вкладки · ${vm.tabs.size}", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            if (vm.closedTabs.isNotEmpty()) {
                TextButton(onClick = { vm.restoreClosedTab(); onClose() }) {
                    Text("Вернуть закрытую", color = c.accent)
                }
            }
            IconButton(onClick = { vm.newTab(); onClose() }) {
                Icon(Icons.Filled.Add, contentDescription = "Новая вкладка")
            }
            TextButton(onClick = onClose) { Text("Готово", color = c.accent) }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(vm.tabs.toList(), key = { it.id }) { tab ->
                TabCard(
                    tab = tab,
                    selected = tab.id == vm.activeTabId,
                    onSelect = { vm.selectTab(tab); onClose() },
                    onClose = { vm.closeTab(tab) },
                )
            }
        }
    }
}

@Composable
private fun TabCard(tab: Tab, selected: Boolean, onSelect: () -> Unit, onClose: () -> Unit) {
    val c = LocalSwaga.current
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .height(112.dp)
            .panel(shape)
            .then(if (selected) Modifier.border(2.dp, c.accent, shape) else Modifier)
            .clickable(onClick = onSelect)
            .padding(start = 14.dp, top = 8.dp, end = 4.dp, bottom = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Text(
                tab.title.ifBlank { if (tab.url == null) "Новая вкладка" else hostOf(tab.url) },
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(top = 6.dp),
            )
            IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Закрыть вкладку", modifier = Modifier.size(18.dp))
            }
        }
        Spacer(Modifier.weight(1f))
        Text(
            if (tab.url == null) "Стартовая страница" else hostOf(tab.url),
            color = c.dim,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
