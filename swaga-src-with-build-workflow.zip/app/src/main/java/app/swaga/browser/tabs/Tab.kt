package app.swaga.browser.tabs

import android.os.Bundle
import android.webkit.WebView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class NavRequest(val url: String) {
    var handled: Boolean = false
}

data class TabSnapshot(val url: String?, val title: String)

/**
 * Состояние одной вкладки. WebView существует только у активной вкладки:
 * при переключении состояние сохраняется в [savedState], а WebView уничтожается.
 */
class Tab(val id: Long, url: String?, title: String) {
    var url by mutableStateOf(url)
    var title by mutableStateOf(title)
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var navRequest by mutableStateOf<NavRequest?>(null)

    var webView: WebView? = null
    var savedState: Bundle? = null
    var onPageLoaded: ((Tab) -> Unit)? = null

    fun load(target: String) {
        error = null
        url = target
        navRequest = NavRequest(target)
    }

    fun resetToStart() {
        url = null
        title = ""
        error = null
        loading = false
        progress = 0
        canGoBack = false
        canGoForward = false
        navRequest = null
        savedState = null
    }

    fun snapshot() = TabSnapshot(url, title)
}
