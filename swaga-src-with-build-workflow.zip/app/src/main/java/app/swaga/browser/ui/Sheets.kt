package app.swaga.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.swaga.browser.BrowserViewModel
import app.swaga.browser.search.SearchEngine
import app.swaga.browser.search.SearchEngines
import app.swaga.browser.themes.AccentChoices
import app.swaga.browser.themes.LocalSwaga
import app.swaga.browser.themes.MaterialId
import app.swaga.browser.themes.ThemeId
import app.swaga.browser.themes.panel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(vm: BrowserViewModel, onDismiss: () -> Unit, onEngines: () -> Unit) {
    val c = LocalSwaga.current
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = c.surface, contentColor = c.text) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Text("Настройки", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)

            Group("Тема") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeId.entries.forEach { t ->
                        FilterChip(selected = vm.themeId == t, onClick = { vm.setTheme(t) }, label = { Text(t.title) })
                    }
                }
            }
            Group("Материал") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MaterialId.entries.forEach { m ->
                        FilterChip(selected = vm.materialId == m, onClick = { vm.setMaterial(m) }, label = { Text(m.title) })
                    }
                }
            }
            Group("Акцентный цвет") {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    AccentChoices.forEachIndexed { i, color ->
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(color)
                                .then(if (vm.accentIndex == i) Modifier.border(3.dp, c.text, CircleShape) else Modifier)
                                .clickable { vm.setAccent(i) },
                        )
                    }
                }
            }
            Group("Поиск") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(onClick = onEngines)
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    EngineBadge(vm.engine, 32.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Поисковая система", fontSize = 15.sp)
                        Text(vm.engine.name, color = c.dim, fontSize = 13.sp)
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = c.dim)
                }
            }
            Text(
                "SwagaBrowser 0.1.0. Движок: системный Android WebView.",
                color = c.dim,
                fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    val c = LocalSwaga.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = c.dim, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        content()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EngineSheet(vm: BrowserViewModel, onDismiss: () -> Unit) {
    val c = LocalSwaga.current
    var name by remember { mutableStateOf(vm.customEngine?.name.orEmpty()) }
    var template by remember { mutableStateOf(vm.customEngine?.searchTemplate.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = c.surface, contentColor = c.text) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Поисковая система", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Результаты всегда открываются во вкладке SwagaBrowser.",
                color = c.dim,
                fontSize = 13.sp,
            )

            vm.engines.forEach { e ->
                EngineRow(e, selected = e.id == vm.engineId) {
                    vm.selectEngine(e.id)
                    onDismiss()
                }
            }

            Text(SearchEngines.PRIVACY_DISCLAIMER, color = c.dim, fontSize = 12.sp)

            Spacer(Modifier.height(4.dp))
            Text("Свой поисковик", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Название") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = template,
                onValueChange = { template = it; error = null },
                label = { Text("Шаблон, например https://example.com/?q=%s") },
                isError = error != null,
                supportingText = { error?.let { Text(it) } },
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = {
                    val err = vm.saveCustomEngine(name, template)
                    if (err == null) onDismiss() else error = err
                },
                colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
            ) { Text("Сохранить и выбрать") }
        }
    }
}

@Composable
private fun EngineRow(e: SearchEngine, selected: Boolean, onClick: () -> Unit) {
    val c = LocalSwaga.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .panel(shape, elevated = true)
            .then(if (selected) Modifier.border(2.dp, c.accent, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        EngineBadge(e, 36.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(e.name, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(e.description, color = c.dim, fontSize = 13.sp)
            Text("Лучше для: ${e.bestFor}", fontSize = 13.sp)
            Text("Приватность: ${e.privacy.label}. ${e.privacyNote}", color = c.dim, fontSize = 12.sp)
        }
        if (selected) {
            Icon(Icons.Filled.Check, contentDescription = "Выбрано", tint = c.accent)
        }
    }
}
