package app.swaga.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.swaga.browser.themes.GlassWindowBlur
import app.swaga.browser.themes.LocalSwaga
import app.swaga.browser.themes.liquidGlass

/**
 * Bottom sheet with a Liquid Glass body. On Android 12+ the page behind it is blurred by the system
 * (see [GlassWindowBlur]); elsewhere the scrim and a denser glass body keep the text readable.
 * Content receives the same [ColumnScope] as a regular ModalBottomSheet.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlassSheet(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = LocalSwaga.current
    val shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.Transparent,
        contentColor = c.text,
        tonalElevation = 0.dp,
        shape = shape,
        scrimColor = Color.Black.copy(alpha = if (c.glass) 0.28f else 0.5f),
        dragHandle = null,
        contentWindowInsets = { WindowInsets(0, 0, 0, 0) },
    ) {
        GlassWindowBlur()
        Column(
            Modifier
                .fillMaxWidth()
                .liquidGlass(shape, elevated = true, frost = 1.55f)
                .navigationBarsPadding(),
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 10.dp, bottom = 4.dp)
                    .width(38.dp)
                    .height(4.dp)
                    .background(c.text.copy(alpha = 0.32f), CircleShape),
            )
            content()
        }
    }
}

/**
 * Dialog with the same glass look. The dialog window is full-screen (so the system blur covers the
 * whole page, not a rectangle around the card) and the card is centred in it.
 */
@Composable
fun GlassDialog(
    onDismissRequest: () -> Unit,
    title: @Composable () -> Unit,
    text: @Composable () -> Unit,
    confirmButton: @Composable () -> Unit,
    dismissButton: @Composable (() -> Unit)? = null,
) {
    val c = LocalSwaga.current
    val shape = RoundedCornerShape(30.dp)
    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        GlassWindowBlur()
        Box(
            Modifier
                .fillMaxSize()
                // The window is full-screen, so a tap outside the card has to dismiss explicitly.
                .pointerInput(Unit) { detectTapGestures { onDismissRequest() } }
                .padding(horizontal = 24.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .liquidGlass(shape, elevated = true, frost = 1.6f)
                    .pointerInput(Unit) { detectTapGestures { } }
                    .padding(horizontal = 22.dp, vertical = 20.dp),
            ) {
                ProvideTextStyle(MaterialTheme.typography.titleLarge.copy(color = c.text)) { title() }
                Spacer(Modifier.height(12.dp))
                ProvideTextStyle(MaterialTheme.typography.bodyMedium.copy(color = c.text)) { text() }
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    dismissButton?.invoke()
                    confirmButton()
                }
            }
        }
    }
}
