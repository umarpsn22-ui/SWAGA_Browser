package app.swaga.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.swaga.browser.BrowserViewModel
import app.swaga.browser.history.Bookmark
import app.swaga.browser.history.HistoryEntry
import app.swaga.browser.search.SearchEngine
import app.swaga.browser.search.SearchEngines
import app.swaga.browser.themes.AccentChoices
import app.swaga.browser.themes.LocalSwaga
import app.swaga.browser.themes.MaterialId
import app.swaga.browser.themes.ThemeId
import app.swaga.browser.themes.panel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(vm: BrowserViewModel, onDismiss: () -> Unit, onEngines: () -> Unit) {
    val c = LocalSwaga.current
    GlassSheet(onDismiss) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Text("Настройки", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)

            Group("Тема") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeId.entries.forEach { t ->
                        FilterChip(selected = vm.themeId == t, onClick = { vm.setTheme(t) }, label = { Text(t.title) })
                    }
                }
            }
            Group("Материал") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MaterialId.entries.forEach { m ->
                        FilterChip(selected = vm.materialId == m, onClick = { vm.setMaterial(m) }, label = { Text(m.title) })
                    }
                }
            }
            Group("Акцентный цвет") {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    AccentChoices.forEachIndexed { i, color ->
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(color)
                                .then(if (vm.accentIndex == i) Modifier.border(3.dp, c.text, CircleShape) else Modifier)
                                .clickable { vm.setAccent(i) },
                        )
                    }
                }
            }
            Group("Защита от трекеров") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Блокировать известные трекеры и рекламные запросы", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("Локальный список доменов. Некоторые сайты могут загружаться иначе.", color = c.dim, fontSize = 12.sp)
                    }
                    Switch(checked = vm.trackingProtectionEnabled, onCheckedChange = vm::setTrackingProtection)
                }
            }
            Group("Приватность") {
                Text(
                    "Режим призрака включается кнопкой «Призрак» в нижней панели. Он скрывает переключатель вкладок и не записывает адреса этого сеанса в историю SwagaBrowser.",
                    color = c.text,
                    fontSize = 13.sp,
                )
                Text(
                    "Это не делает соединение анонимным: посещаемые сайты и интернет-провайдер всё ещё могут получать сетевые данные.",
                    color = c.dim,
                    fontSize = 12.sp,
                )
            }
            Group("Данные браузера") {
                Text("Удаляет локальную историю, cookies, временный кэш и данные форм. Закладки и настройки останутся.", color = c.dim, fontSize = 12.sp)
                Button(
                    onClick = vm::clearBrowsingData,
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent.copy(alpha = 0.22f), contentColor = c.text),
                ) { Text("Очистить данные браузера") }
            }
            Group("Поиск") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(onClick = onEngines)
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    EngineBadge(vm.engine, 32.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Поисковая система", fontSize = 15.sp)
                        Text(vm.engine.name, color = c.dim, fontSize = 13.sp)
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = c.dim)
                }
            }
            Text(
                "#SWAGA_Browser 0.5.0. Движок: Android WebView.",
                color = c.dim,
                fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    val c = LocalSwaga.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = c.dim, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        content()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EngineSheet(vm: BrowserViewModel, onDismiss: () -> Unit) {
    val c = LocalSwaga.current
    var name by remember { mutableStateOf(vm.customEngine?.name.orEmpty()) }
    var template by remember { mutableStateOf(vm.customEngine?.searchTemplate.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }

    GlassSheet(onDismiss) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Поисковая система", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Результаты всегда открываются во вкладке SwagaBrowser.",
                color = c.dim,
                fontSize = 13.sp,
            )

            vm.engines.forEach { e ->
                EngineRow(e, selected = e.id == vm.engineId) {
                    vm.selectEngine(e.id)
                    onDismiss()
                }
            }

            Text(SearchEngines.PRIVACY_DISCLAIMER, color = c.dim, fontSize = 12.sp)

            Spacer(Modifier.height(4.dp))
            Text("Свой поисковик", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Название") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = template,
                onValueChange = { template = it; error = null },
                label = { Text("Шаблон, например https://example.com/?q=%s") },
                isError = error != null,
                supportingText = { error?.let { Text(it) } },
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = {
                    val err = vm.saveCustomEngine(name, template)
                    if (err == null) onDismiss() else error = err
                },
                colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
            ) { Text("Сохранить и выбрать") }
        }
    }
}

@Composable
private fun EngineRow(e: SearchEngine, selected: Boolean, onClick: () -> Unit) {
    val c = LocalSwaga.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .panel(shape, elevated = true)
            .then(if (selected) Modifier.border(2.dp, c.accent, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        EngineBadge(e, 36.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(e.name, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(e.description, color = c.dim, fontSize = 13.sp)
            Text("Лучше для: ${e.bestFor}", fontSize = 13.sp)
            Text("Приватность: ${e.privacy.label}. ${e.privacyNote}", color = c.dim, fontSize = 12.sp)
        }
        if (selected) {
            Icon(Icons.Filled.Check, contentDescription = "Выбрано", tint = c.accent)
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderSheet(vm: BrowserViewModel, onDismiss: () -> Unit) {
    val c = LocalSwaga.current
    GlassSheet(onDismiss) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp).padding(bottom = 34.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Режим чтения", color = c.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text(vm.readerTitle, fontSize = 23.sp, lineHeight = 29.sp, fontWeight = FontWeight.Bold)
            Text(vm.readerUrl, color = c.dim, fontSize = 11.sp, maxLines = 2)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { vm.changeReaderTextSize(-10) }) { Text("A−", color = c.accent) }
                Text("${vm.readerTextScale}%", color = c.dim, fontSize = 12.sp)
                TextButton(onClick = { vm.changeReaderTextSize(10) }) { Text("A+", color = c.accent) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDismiss) { Text("Готово", color = c.accent) }
            }
            when {
                vm.readerLoading -> Text("Извлекаю текст страницы…", color = c.dim, fontSize = 14.sp)
                vm.readerText.isNullOrBlank() -> Text("На этой странице не найден основной текст. Попробуй другую страницу.", color = c.dim, fontSize = 14.sp)
                else -> androidx.compose.foundation.text.selection.SelectionContainer {
                    Text(
                        vm.readerText.orEmpty(),
                        color = c.text,
                        fontSize = (16f * vm.readerTextScale / 100f).sp,
                        lineHeight = (27f * vm.readerTextScale / 100f).sp,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistorySheet(vm: BrowserViewModel, onDismiss: () -> Unit, onOpen: (String) -> Unit) {
    val c = LocalSwaga.current
    GlassSheet(onDismiss) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 30.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("История посещений", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                TextButton(onClick = vm::clearHistory) { Text("Очистить", color = c.accent) }
            }
            Text("Хранится только на этом устройстве. До 500 последних адресов.", color = c.dim, fontSize = 12.sp)
            if (vm.history.isEmpty()) {
                Text("История пока пуста.", color = c.dim, fontSize = 14.sp)
            } else {
                vm.history.forEach { item ->
                    Row(
                        Modifier.fillMaxWidth().panel(RoundedCornerShape(16.dp)).clickable { onOpen(item.url) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(item.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(android.net.Uri.parse(item.url).host.orEmpty(), color = c.dim, fontSize = 11.sp, maxLines = 1)
                        }
                        TextButton(onClick = { vm.removeHistoryEntry(item) }) { Text("Убрать", color = c.dim) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarksSheet(vm: BrowserViewModel, onDismiss: () -> Unit, onOpen: (String) -> Unit) {
    val c = LocalSwaga.current
    GlassSheet(onDismiss) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Закладки", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            if (vm.bookmarks.isEmpty()) {
                Text("Здесь будут сохранённые сайты.", color = c.dim, fontSize = 14.sp)
            } else {
                vm.bookmarks.forEach { bookmark ->
                    Row(
                        Modifier.fillMaxWidth().panel(RoundedCornerShape(16.dp), elevated = true).clickable { onOpen(bookmark.url) }.padding(13.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(bookmark.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(bookmark.url, color = c.dim, fontSize = 11.sp, maxLines = 1)
                        }
                        TextButton(onClick = { vm.removeBookmark(bookmark) }) { Text("Удалить", color = c.dim) }
                    }
                }
            }
        }
    }
}
