package app.swaga.browser.ui

import android.net.Uri
import android.widget.VideoView
import app.swaga.browser.R
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.DisposableEffect
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.swaga.browser.BrowserViewModel
import app.swaga.browser.themes.LocalSwaga
import app.swaga.browser.themes.glassButton
import app.swaga.browser.themes.glassTileBrush
import app.swaga.browser.themes.panel

private data class QuickLink(val title: String, val url: String)

private val quickLinks = listOf(
    QuickLink("Wikipedia", "https://ru.wikipedia.org"),
    QuickLink("YouTube", "https://www.youtube.com"),
    QuickLink("GitHub", "https://github.com"),
    QuickLink("Telegram", "https://web.telegram.org"),
    QuickLink("VK", "https://vk.com"),
    QuickLink("Habr", "https://habr.com"),
    QuickLink("Reddit", "https://www.reddit.com"),
    QuickLink("Карты", "https://www.openstreetmap.org"),
)

@Composable
fun StartPage(
    vm: BrowserViewModel,
    onEngines: () -> Unit,
    onSettings: () -> Unit,
) {
    val c = LocalSwaga.current
    val focusManager = LocalFocusManager.current
    var query by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
    Modifier
        .fillMaxWidth()
        .padding(top = 14.dp, bottom = 4.dp)
        .panel(RoundedCornerShape(22.dp), elevated = true)
        .padding(horizontal = 14.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
      Text(
        "#SWAGA_Browser",
        color = c.text,
        fontSize = 19.sp,
        fontWeight = FontWeight.Black,
        letterSpacing = (-0.65).sp,
      )
      Text(
        "Высокий шанс на свагу,#SWAGA_Browser",
        color = c.dim,
        fontSize = 10.sp,
        fontWeight = FontWeight.Medium,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
    Box(
      Modifier.size(40.dp).glassButton(CircleShape, onClick = onSettings),
      contentAlignment = Alignment.Center,
    ) {
      Icon(Icons.Filled.Settings, contentDescription = "Настройки", tint = c.text, modifier = Modifier.size(19.dp))
    }
  }

            Spacer(Modifier.height(18.dp))
  SwagaHero()
  Spacer(Modifier.height(14.dp))

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(61.dp)
                    .panel(RoundedCornerShape(23.dp), elevated = true)
                    .padding(start = 11.dp, end = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                EngineBadge(vm.engine, 35.dp, Modifier.clickable { onEngines() })
                Spacer(Modifier.width(11.dp))
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium),
                    cursorBrush = SolidColor(c.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search, keyboardType = KeyboardType.Uri),
                    keyboardActions = KeyboardActions(onSearch = {
                        vm.submit(query)
                        query = ""
                        focusManager.clearFocus()
                    }),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isEmpty()) {
                                Text("Поиск или адрес сайта", color = c.dim, fontSize = 14.sp)
                            }
                            inner()
                        }
                    },
                )
                Box(
                    Modifier
                        .size(45.dp)
                        .clip(RoundedCornerShape(17.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(c.accent.copy(alpha = 0.25f), c.accent.copy(alpha = 0.10f)),
                            ),
                        )
                        .clickable {
                            vm.submit(query)
                            query = ""
                            focusManager.clearFocus()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Search, contentDescription = "Искать", tint = c.accent, modifier = Modifier.size(21.dp))
                }
            }

            Spacer(Modifier.height(19.dp))


            if (vm.ghostModeEnabled) {
                Spacer(Modifier.height(16.dp))
                Row(
                    Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(c.accent.copy(alpha = 0.13f))
                        .padding(horizontal = 13.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(c.accent))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "ПРИВАТНЫЙ СЕАНС АКТИВЕН",
                        color = c.accent,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.85.sp,
                    )
                }
            }

            Spacer(Modifier.height(22.dp))
            quickLinks.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { link ->
                        Tile(link.title, Modifier.weight(1f)) { vm.submit(link.url) }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
                Spacer(Modifier.height(10.dp))
            }

            if (vm.bookmarks.isNotEmpty() && !vm.ghostModeEnabled) {
                Spacer(Modifier.height(23.dp))
                SectionTitle("ИЗБРАННОЕ")
                Spacer(Modifier.height(9.dp))
                vm.bookmarks.take(3).forEach { bookmark ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .glassButton(RoundedCornerShape(16.dp)) { vm.submit(bookmark.url) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Letter(hostOf(bookmark.url), 34.dp)
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(bookmark.title, color = c.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(hostOf(bookmark.url), color = c.dim, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text("↗", color = c.dim, fontSize = 16.sp)
                    }
                    Spacer(Modifier.height(7.dp))
                }
            }

            Spacer(Modifier.height(34.dp))
        }
    }
}

@Composable
private fun SwagaHero() {
    val c = LocalSwaga.current
    Row(
        Modifier.fillMaxWidth().height(106.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Text(
                "#SWAGAA",
                color = Color(0xFFF7F9FF),
                fontSize = 46.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-3.6).sp,
                maxLines = 1,
                softWrap = false,
                style = TextStyle(
                    shadow = Shadow(c.text.copy(alpha = 0.20f), Offset(0f, 2f), 10f),
                ),
            )
        }
        Spacer(Modifier.width(8.dp))
        SwagaHeroVideo()
    }
}

@Composable
private fun SwagaHeroVideo() {
    val context = LocalContext.current
    val videoView = remember(context) {
        VideoView(context).apply {
            setVideoURI(Uri.parse("android.resource://" + context.packageName + "/" + R.raw.swaga_hero))
            setOnPreparedListener { player ->
                player.isLooping = true
                player.setVolume(0f, 0f)
                start()
            }
        }
    }
    DisposableEffect(videoView) {
        onDispose { videoView.stopPlayback() }
    }
    Box(
        Modifier
            .size(56.dp)
            .panel(RoundedCornerShape(15.dp), elevated = true)
            .clip(RoundedCornerShape(15.dp)),
    ) {
        AndroidView(
            factory = { videoView },
            modifier = Modifier.fillMaxSize(),
            update = { /* VideoView starts from OnPreparedListener only. */ },
        )
    }
}

@Composable
private fun StartAction(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalSwaga.current
    Box(
        modifier
            .height(43.dp)
            .panel(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = c.text,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    val c = LocalSwaga.current
    Text(text, color = c.dim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.35.sp)
}

@Composable
private fun Tile(title: String, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalSwaga.current
    Column(
        modifier
            .height(82.dp)
            .glassButton(RoundedCornerShape(18.dp), elevated = true, onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Letter(title, 39.dp)
        Spacer(Modifier.height(5.dp))
        Text(
            title,
            color = c.text,
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun Letter(label: String, size: androidx.compose.ui.unit.Dp) {
    val c = LocalSwaga.current
    val px = with(androidx.compose.ui.platform.LocalDensity.current) { size.toPx() }
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(13.dp))
            .background(glassTileBrush(c, androidx.compose.ui.geometry.Size(px, px))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label.take(1).uppercase(),
            color = c.text,
            fontSize = (size.value * 0.41f).sp,
            fontWeight = FontWeight.Bold,
        )
    }
}
