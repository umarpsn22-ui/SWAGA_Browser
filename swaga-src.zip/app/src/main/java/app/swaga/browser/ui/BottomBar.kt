package app.swaga.browser.ui

import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.app.DownloadManager
import app.swaga.browser.MainActivity
import app.swaga.browser.R
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.swaga.browser.BrowserViewModel
import app.swaga.browser.tabs.Tab
import app.swaga.browser.themes.LocalSwaga
import app.swaga.browser.themes.glassButton
import app.swaga.browser.themes.liquidGlass
import app.swaga.browser.themes.panel

@Composable
fun BottomBar(
    vm: BrowserViewModel,
    tab: Tab?,
    onTabs: () -> Unit,
    onSettings: () -> Unit,
    onEngines: () -> Unit,
    onBookmarks: () -> Unit,
    onHistory: () -> Unit,
    onReader: () -> Unit,
) {
    val ctx = LocalContext.current
    val c = LocalSwaga.current
    var menu by remember { mutableStateOf(false) }
    var showFind by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    val onPage = tab != null && tab.url != null

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 7.dp)
            .panel(RoundedCornerShape(27.dp), elevated = true)
            .padding(horizontal = 4.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        if (tab != null && onPage) {
            IconButton(onClick = {
                if (tab.canGoBack) tab.webView?.goBack() else vm.closeToStart(tab)
            }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
            }
            key(tab.id) {
                AddressPill(vm = vm, tab = tab, onEngines = onEngines, modifier = Modifier.weight(1f))
            }
        } else {
            Spacer(Modifier.weight(1f))
        }

        GhostModeButton(active = vm.ghostModeEnabled, onClick = vm::toggleGhostMode)

        if (!vm.ghostModeEnabled) {
            IconButton(onClick = onTabs, modifier = Modifier.size(40.dp)) {
                TabsCountIcon(vm.tabs.size)
            }
        }

        Box {
            IconButton(onClick = { menu = true }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Меню")
            }
            val menuShape = RoundedCornerShape(22.dp)
            DropdownMenu(
                expanded = menu,
                onDismissRequest = { menu = false },
                shape = menuShape,
                containerColor = Color.Transparent,
                tonalElevation = 0.dp,
                shadowElevation = 0.dp,
                modifier = Modifier.liquidGlass(menuShape, elevated = true, frost = 1.7f),
            ) {
                if (!vm.ghostModeEnabled) {
                    DropdownMenuItem(
                        text = { Text("Новая вкладка") },
                        onClick = { menu = false; vm.newTab() },
                    )
                    DropdownMenuItem(
                        text = { Text("Восстановить закрытую вкладку") },
                        enabled = vm.closedTabs.isNotEmpty(),
                        onClick = { menu = false; vm.restoreClosedTab() },
                    )
                }
                DropdownMenuItem(
                    text = { Text(if (vm.ghostModeEnabled) "Выйти из режима призрака" else "Включить режим призрака") },
                    onClick = { menu = false; vm.toggleGhostMode() },
                )
                DropdownMenuItem(
                    text = { Text("Вперёд") },
                    enabled = tab?.canGoForward == true,
                    onClick = { menu = false; tab?.webView?.goForward() },
                )
                DropdownMenuItem(
                    text = { Text(if (tab?.loading == true) "Остановить" else "Обновить") },
                    enabled = onPage,
                    onClick = {
                        menu = false
                        if (tab?.loading == true) tab.webView?.stopLoading() else tab?.webView?.reload()
                    },
                )
                if (!vm.ghostModeEnabled) {
                    DropdownMenuItem(
                        text = { Text(if (vm.isBookmarked(tab?.url)) "Убрать из закладок" else "Добавить в закладки") },
                        enabled = onPage,
                        onClick = { menu = false; vm.toggleBookmark(tab) },
                    )
                    DropdownMenuItem(
                        text = { Text("Закладки") },
                        onClick = { menu = false; onBookmarks() },
                    )
                }
                DropdownMenuItem(
                    text = { Text("Режим чтения") },
                    enabled = onPage,
                    onClick = { menu = false; onReader() },
                )
                DropdownMenuItem(
                    text = { Text("Увеличить текст") },
                    enabled = onPage,
                    onClick = { menu = false; vm.changePageTextZoom(tab, 10) },
                )
                DropdownMenuItem(
                    text = { Text("Уменьшить текст") },
                    enabled = onPage,
                    onClick = { menu = false; vm.changePageTextZoom(tab, -10) },
                )
                DropdownMenuItem(
                    text = { Text("Перевести страницу на русский") },
                    enabled = onPage && !tab?.url.isNullOrBlank(),
                    onClick = {
                        menu = false
                        val url = tab?.url
                        if (!url.isNullOrBlank()) vm.submit("https://translate.google.com/translate?sl=auto&tl=ru&u=${Uri.encode(url)}")
                    },
                )
                DropdownMenuItem(
                    text = { Text("Загрузки") },
                    onClick = {
                        menu = false
                        runCatching { ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
                    },
                )
                DropdownMenuItem(
                    text = { Text("Ярлык на главный экран") },
                    enabled = onPage && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O,
                    onClick = {
                        menu = false
                        val url = tab?.url
                        if (!url.isNullOrBlank()) {
                            val manager = ctx.getSystemService(ShortcutManager::class.java)
                            if (manager?.isRequestPinShortcutSupported == true) {
                                val shortcutIntent = Intent(ctx, MainActivity::class.java).apply {
                                    action = Intent.ACTION_VIEW
                                    data = Uri.parse(url)
                                }
                                val label = (tab?.title?.ifBlank { Uri.parse(url).host ?: "Сайт" } ?: "Сайт").take(24)
                                val shortcut = ShortcutInfo.Builder(ctx, "swaga-${url.hashCode()}")
                                    .setShortLabel(label)
                                    .setLongLabel(label)
                                    .setIcon(Icon.createWithResource(ctx, R.mipmap.ic_launcher))
                                    .setIntent(shortcutIntent)
                                    .build()
                                manager.requestPinShortcut(shortcut, null)
                            } else vm.message = "Этот лаунчер не поддерживает ярлыки."
                        }
                    },
                )
                DropdownMenuItem(
                    text = { Text("Копировать адрес") },
                    enabled = onPage,
                    onClick = {
                        menu = false
                        val url = tab?.url
                        if (!url.isNullOrBlank()) {
                            val clipboard = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Адрес страницы", url))
                            vm.message = "Адрес скопирован."
                        }
                    },
                )
                DropdownMenuItem(
                    text = { Text("Найти на странице") },
                    enabled = onPage,
                    onClick = { menu = false; findQuery = ""; showFind = true },
                )
                DropdownMenuItem(
                    text = { Text(if (tab?.desktopMode == true) "Мобильная версия" else "Версия для компьютера") },
                    enabled = onPage,
                    onClick = { menu = false; tab?.let(vm::toggleDesktopMode) },
                )
                DropdownMenuItem(
                    text = { Text("Поделиться ссылкой") },
                    enabled = onPage,
                    onClick = {
                        menu = false
                        val url = tab?.url
                        if (url != null) {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, url)
                            }
                            ctx.startActivity(Intent.createChooser(send, null))
                        }
                    },
                )
                if (!vm.ghostModeEnabled) {
                    DropdownMenuItem(
                        text = { Text("История посещений") },
                        onClick = { menu = false; onHistory() },
                    )
                }
                DropdownMenuItem(
                    text = { Text("Настройки") },
                    onClick = { menu = false; onSettings() },
                )
            }
        }
    }

    if (showFind) {
        GlassDialog(
            onDismissRequest = { showFind = false; tab?.webView?.clearMatches() },
            title = { Text("Найти на странице") },
            text = {
                OutlinedTextField(
                    value = findQuery,
                    onValueChange = { findQuery = it },
                    singleLine = true,
                    label = { Text("Текст для поиска") },
                )
            },
            confirmButton = {
                TextButton(onClick = { if (findQuery.isNotBlank()) { tab?.webView?.findAllAsync(findQuery) } }) { Text("Далее") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { tab?.webView?.findNext(false) }) { Text("Назад") }
                    TextButton(onClick = { showFind = false; tab?.webView?.clearMatches() }) { Text("Готово") }
                }
            },
        )
    }
}

@Composable
private fun GhostModeButton(active: Boolean, onClick: () -> Unit) {
    val c = LocalSwaga.current
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .glassButton(shape, onClick = onClick)
            .then(
                if (active) Modifier.background(c.accent.copy(alpha = 0.20f), shape)
                    .border(1.dp, c.accent.copy(alpha = 0.72f), shape)
                else Modifier,
            )
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Icon(
            Icons.Filled.Lock,
            contentDescription = if (active) "Режим призрака включён" else "Включить режим призрака",
            tint = if (active) c.accent else c.text,
            modifier = Modifier.size(15.dp),
        )
        Text(
            if (active) "Выйти" else "Призрак",
            color = if (active) c.accent else c.text,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
fun AddressPill(
    vm: BrowserViewModel,
    tab: Tab,
    onEngines: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = LocalSwaga.current
    val focusManager = LocalFocusManager.current
    var focused by remember { mutableStateOf(false) }
    var field by remember { mutableStateOf(TextFieldValue(hostOf(tab.url))) }

    LaunchedEffect(tab.url, focused) {
        if (!focused) field = TextFieldValue(hostOf(tab.url))
    }

    Row(
        modifier
            .height(44.dp)
            .panel(RoundedCornerShape(22.dp))
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        EngineBadge(vm.engine, 28.dp, Modifier.clickable { onEngines() })
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = field,
            onValueChange = { field = it },
            singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 14.sp),
            cursorBrush = SolidColor(c.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
            keyboardActions = KeyboardActions(onGo = {
                vm.submit(field.text)
                focusManager.clearFocus()
            }),
            modifier = Modifier
                .weight(1f)
                .onFocusChanged { st ->
                    if (st.isFocused) {
                        if (!focused) {
                            focused = true
                            val u = tab.url.orEmpty()
                            field = TextFieldValue(u, TextRange(0, u.length))
                        }
                    } else {
                        focused = false
                    }
                },
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (field.text.isEmpty()) Text("Поиск или адрес", color = c.dim, fontSize = 14.sp)
                    inner()
                }
            },
        )
        if (!focused) {
            val https = tab.url?.startsWith("https://") == true
            Icon(
                imageVector = if (https) Icons.Filled.Lock else Icons.Filled.Warning,
                contentDescription = if (https) "Соединение по HTTPS" else "Соединение без шифрования",
                tint = if (https) c.dim else Color(0xFFE6A23C),
                modifier = Modifier.padding(end = 6.dp).size(16.dp),
            )
        }
    }
}
