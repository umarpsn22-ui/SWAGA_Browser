package app.swaga.browser.tabs

import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.swaga.browser.engine.SwagaGeckoTab
import org.mozilla.geckoview.GeckoSession

class NavRequest(val url: String) {
    var handled: Boolean = false
}

data class TabSnapshot(val url: String?, val title: String)

/**
 * Состояние одной вкладки. GeckoSession живёт, пока вкладка не закрыта и не вытеснена
 * из ограниченного пула живых сессий (см. BrowserViewModel.enforceSessionBudget). При
 * вытеснении страница не теряется: [sessionState] хранит историю, позицию и данные форм,
 * и при следующем открытии сессия восстанавливается из него, а не грузится заново.
 */
class Tab(val id: Long, url: String?, title: String) {
    var url by mutableStateOf(url)
    var title by mutableStateOf(title)
    var progress by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    var desktopMode by mutableStateOf(false)
    var textZoom by mutableIntStateOf(100)
    var error by mutableStateOf<String?>(null)
    var navRequest by mutableStateOf<NavRequest?>(null)

    var webView: SwagaGeckoTab? = null
    var ghostSession: Boolean = false
    var savedState: Bundle? = null

    /** Последнее состояние сессии Gecko (история, прокрутка, формы). Только в памяти. */
    var sessionState: GeckoSession.SessionState? = null

    /** Время последнего показа вкладки — для вытеснения самых давних сессий. */
    var lastUsed: Long = 0L
    var onPageLoaded: ((Tab) -> Unit)? = null

    fun load(target: String) {
        error = null
        url = target
        navRequest = NavRequest(target)
    }

    fun resetToStart() {
        url = null
        title = ""
        error = null
        loading = false
        progress = 0
        canGoBack = false
        canGoForward = false
        navRequest = null
        savedState = null
    }

    fun snapshot() = TabSnapshot(url, title)
}
