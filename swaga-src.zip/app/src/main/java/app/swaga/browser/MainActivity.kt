package app.swaga.browser

import android.content.ComponentCallbacks2
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import app.swaga.browser.engine.SwagaGeckoTab
import app.swaga.browser.themes.SwagaTheme
import app.swaga.browser.ui.BrowserApp

class MainActivity : ComponentActivity() {

    private val vm: BrowserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            SwagaTheme(vm.themeId, vm.materialId, vm.accentIndex) {
                BrowserApp(vm)
            }
        }
        // Create the Gecko runtime right after the first frame, so the start page appears at once
        // and the first opened page does not have to pay for engine start-up.
        Handler(Looper.getMainLooper()).postDelayed({ SwagaGeckoTab.prewarm(applicationContext) }, 700)
    }

    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // Under real memory pressure keep only the visible tab's session alive.
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) vm.trimSessions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onStop() {
        vm.persist()
        super.onStop()
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_VIEW) {
            i.dataString?.let { vm.openExternal(it) }
        }
    }
}
