package app.swaga.browser

import android.os.SystemClock
import app.swaga.browser.engine.SwagaGeckoTab

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import app.swaga.browser.history.Bookmark
import app.swaga.browser.history.BookmarkStore
import app.swaga.browser.history.HistoryEntry
import app.swaga.browser.history.HistoryStore
import app.swaga.browser.history.RecentSite
import app.swaga.browser.history.RecentStore
import app.swaga.browser.search.SearchEngine
import app.swaga.browser.search.SearchEngines
import app.swaga.browser.search.UrlResolver
import app.swaga.browser.tabs.Tab
import app.swaga.browser.tabs.TabSnapshot
import app.swaga.browser.tabs.TabStore
import app.swaga.browser.engine.SwagaWebView
import org.json.JSONObject
import app.swaga.browser.themes.MaterialId
import app.swaga.browser.themes.ThemeId

class BrowserViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("swaga", Context.MODE_PRIVATE)
    private val tabStore = TabStore(prefs)
    private val recentStore = RecentStore(prefs)
    private val bookmarkStore = BookmarkStore(prefs)
    private val historyStore = HistoryStore(prefs)

    var themeId by mutableStateOf(ThemeId.MIDNIGHT)
        private set
    var materialId by mutableStateOf(MaterialId.GLASS)
        private set
    var accentIndex by mutableIntStateOf(0)
        private set
    var engineId by mutableStateOf("ddg")
        private set
    var customEngine by mutableStateOf<SearchEngine?>(null)
        private set

    var trackingProtectionEnabled by mutableStateOf(true)
        private set
    var readerTitle by mutableStateOf("")
        private set
    var readerUrl by mutableStateOf("")
        private set
    var readerText by mutableStateOf<String?>(null)
        private set
    var readerLoading by mutableStateOf(false)
        private set
    var readerTextScale by mutableIntStateOf(100)
        private set

    /** True only for the current in-memory browsing session. Never persisted. */
    var ghostModeEnabled by mutableStateOf(false)
        private set
    var ghostTransition by mutableIntStateOf(0)
        private set
    var ghostTransitionEntering by mutableStateOf(true)
        private set

    private var restoreUrlAfterGhost: String? = null
    private var restoreTitleAfterGhost: String = ""

    /** Одноразовое сообщение для Snackbar. */
    var message by mutableStateOf<String?>(null)

    val tabs = mutableStateListOf<Tab>()
    var activeTabId by mutableLongStateOf(-1L)
        private set
    val closedTabs = mutableStateListOf<TabSnapshot>()
    val recent = mutableStateListOf<RecentSite>()
    val bookmarks = mutableStateListOf<Bookmark>()
    val history = mutableStateListOf<HistoryEntry>()

    private var nextId = 1L

    private companion object {
        /** Активная вкладка + самые недавние; остальные восстанавливаются из sessionState. */
        const val MAX_LIVE_SESSIONS = 4
    }

    val activeTab: Tab? get() = tabs.firstOrNull { it.id == activeTabId }
    val engines: List<SearchEngine> get() = SearchEngines.builtIn + listOfNotNull(customEngine)
    val engine: SearchEngine get() = engines.firstOrNull { it.id == engineId } ?: SearchEngines.builtIn.first { it.id == "ddg" }

    init {
        themeId = runCatching { ThemeId.valueOf(prefs.getString("theme", "") ?: "") }.getOrDefault(ThemeId.MIDNIGHT)
        materialId = runCatching { MaterialId.valueOf(prefs.getString("material", "") ?: "") }.getOrDefault(MaterialId.GLASS)
        accentIndex = prefs.getInt("accent", 0)
        trackingProtectionEnabled = prefs.getBoolean("tracking_protection", true)
        SwagaWebView.trackingProtectionEnabled = trackingProtectionEnabled
        engineId = prefs.getString("engine", "ddg") ?: "ddg"
        val tpl = prefs.getString("custom_tpl", null)
        if (tpl != null && SearchEngines.validateTemplate(tpl) == null) {
            customEngine = SearchEngines.custom(prefs.getString("custom_name", "") ?: "", tpl)
        }
        recent.addAll(recentStore.load())
        bookmarks.addAll(bookmarkStore.load())
        history.addAll(historyStore.load())

        val (snaps, active) = tabStore.load()
        if (snaps.isEmpty()) {
            newTab()
        } else {
            snaps.forEach { tabs.add(createTab(it.url, it.title)) }
            activeTabId = tabs[active.coerceIn(0, tabs.lastIndex)].id
        }
    }

    // ---- Настройки ----

    fun setTheme(t: ThemeId) { themeId = t; prefs.edit().putString("theme", t.name).apply() }
    fun setMaterial(m: MaterialId) { materialId = m; prefs.edit().putString("material", m.name).apply() }
    fun setAccent(i: Int) { accentIndex = i; prefs.edit().putInt("accent", i).apply() }

    fun setTrackingProtection(enabled: Boolean) {
        trackingProtectionEnabled = enabled
        prefs.edit().putBoolean("tracking_protection", enabled).apply()
        SwagaWebView.trackingProtectionEnabled = enabled
        activeTab?.webView?.setTrackingProtection(enabled)
        message = if (enabled) "Защита от известных трекеров включена." else "Защита от трекеров выключена."
    }

    fun clearBrowsingData() {
        SwagaGeckoTab.clearSiteData(getApplication())
        tabs.forEach { tab ->
            tab.webView?.apply {
                clearHistory()
                clearCache(true)
                clearFormData()
            }
            tab.savedState = null
        }
        recentStore.clear()
        historyStore.clear()
        recent.clear()
        history.clear()
        message = "История, cookies и кэш очищены."
    }

    fun prepareReader(tab: Tab? = activeTab) {
        val current = tab
        if (current == null) {
            message = "Сначала открой страницу."
            return
        }
        val target = current.webView
        if (target == null) {
            message = "Страница ещё загружается. Попробуй снова через секунду."
            return
        }
        readerTitle = current.title.ifBlank { "Режим чтения" }
        readerUrl = current.url.orEmpty()
        readerText = null
        readerLoading = true
        val script = """(function() {
            const root = document.querySelector('article') || document.querySelector('[role=main]') || document.querySelector('main') || document.body;
            const clone = root.cloneNode(true);
            clone.querySelectorAll('script,style,nav,header,footer,aside,form,button,iframe,svg,noscript').forEach(n => n.remove());
            const text = (clone.innerText || '').replace(/\n{3,}/g, '\n\n').trim().slice(0, 40000);
            return { title: document.title || '', text: text };
        })()"""
        target.evaluateJavascript(script) { result ->
            val payload = runCatching { JSONObject(result ?: "{}") }.getOrNull()
            val extracted = payload?.optString("text").orEmpty()
            readerTitle = payload?.optString("title")?.takeIf { it.isNotBlank() } ?: readerTitle
            readerText = extracted.takeIf { it.isNotBlank() }
            readerLoading = false
            if (readerText == null) message = "Не удалось извлечь текст этой страницы."
        }
    }

    fun closeReader() {
        readerText = null
        readerLoading = false
    }

    fun changeReaderTextSize(delta: Int) {
        readerTextScale = (readerTextScale + delta).coerceIn(80, 150)
    }

    fun changePageTextZoom(tab: Tab? = activeTab, delta: Int) {
        val target = tab ?: return
        target.textZoom = (target.textZoom + delta).coerceIn(70, 200)
        target.webView?.settings?.textZoom = target.textZoom
        message = "Масштаб текста: ${target.textZoom}%"
    }

    fun removeHistoryEntry(entry: HistoryEntry) {
        history.remove(entry)
        historyStore.remove(entry)
    }

    fun clearHistory() {
        history.clear()
        historyStore.clear()
        recentStore.clear()
        recent.clear()
        message = "История посещений очищена."
    }

    fun selectEngine(id: String) {
        if (engines.none { it.id == id }) return
        engineId = id
        prefs.edit().putString("engine", id).apply()
    }

    /** Returns an error, or null when the custom engine was saved. */
    fun saveCustomEngine(name: String, template: String): String? {
        SearchEngines.validateTemplate(template)?.let { return it }
        customEngine = SearchEngines.custom(name, template)
        prefs.edit().putString("custom_name", name.trim()).putString("custom_tpl", template.trim()).apply()
        selectEngine("custom")
        return null
    }


    fun isBookmarked(url: String?): Boolean = url != null && bookmarks.any { it.url == url }

    fun toggleBookmark(tab: Tab? = activeTab) {
        if (ghostModeEnabled) {
            message = "Закладки недоступны в режиме призрака."
            return
        }
        val url = tab?.url ?: return
        val existing = bookmarks.firstOrNull { it.url == url }
        if (existing != null) {
            bookmarks.remove(existing)
            message = "Закладка удалена."
        } else {
            val title = tab.title.ifBlank { android.net.Uri.parse(url).host ?: url }
            bookmarks.add(0, Bookmark(title, url))
            message = "Добавлено в закладки."
        }
        bookmarkStore.save(bookmarks.toList())
    }

    fun removeBookmark(bookmark: Bookmark) {
        bookmarks.remove(bookmark)
        bookmarkStore.save(bookmarks.toList())
    }

    fun toggleDesktopMode(tab: Tab) {
        val webView = tab.webView ?: return
        tab.desktopMode = !tab.desktopMode
        webView.setDesktopMode(tab.desktopMode)
        message = if (tab.desktopMode) "Версия для компьютера включена." else "Мобильная версия включена." 
    }

    fun clearRecent() {
        if (ghostModeEnabled) return
        recentStore.clear()
        recent.clear()
    }

    /**
     * Switches the currently visible tab into a temporary private session.
     * The normal page is remembered in memory and restored when Ghost Mode exits.
     * Ghost Mode state and visited pages are deliberately never written to TabStore.
     */
    fun setGhostMode(enabled: Boolean) {
        if (ghostModeEnabled == enabled) return
        message = null
        val tab = activeTab ?: newTab()

        if (enabled) {
            restoreUrlAfterGhost = tab.url
            restoreTitleAfterGhost = tab.title
            ghostModeEnabled = true
            ghostTransitionEntering = true

            tab.ghostSession = true
            tab.webView?.setPrivateMode(true)
            tab.webView?.clearHistory()
            tab.savedState = null
        } else {
            ghostModeEnabled = false
            ghostTransitionEntering = false
            tab.ghostSession = false
            tab.webView?.setPrivateMode(false)
            tab.webView?.clearHistory()
            val returnUrl = restoreUrlAfterGhost
            tab.title = restoreTitleAfterGhost
            restoreUrlAfterGhost = null
            restoreTitleAfterGhost = ""
            if (returnUrl.isNullOrBlank()) {
                tab.resetToStart()
            } else {
                tab.load(returnUrl)
            }
        }
        ghostTransition++
    }

    fun toggleGhostMode() = setGhostMode(!ghostModeEnabled)

    // ---- Вкладки ----

    private fun createTab(url: String?, title: String): Tab =
        Tab(nextId++, url, title).also { tab ->
            tab.onPageLoaded = { loaded ->
                val u = loaded.url
                if (!ghostModeEnabled && u != null) {
                    val nextHistory = historyStore.add(history.toList(), loaded.title, u)
                    history.clear()
                    history.addAll(nextHistory)
                    val next = recentStore.add(recent.toList(), loaded.title, u)
                    recent.clear()
                    recent.addAll(next)
                }
            }
        }

    fun newTab(url: String? = null, select: Boolean = true): Tab {
        if (ghostModeEnabled) {
            val current = activeTab ?: createTab(null, "")
            if (tabs.none { it.id == current.id }) tabs.add(current)
            if (url != null) current.load(url)
            if (select) activeTabId = current.id
            return current
        }
        val tab = createTab(url, "")
        if (url != null) tab.navRequest = app.swaga.browser.tabs.NavRequest(url)
        tabs.add(tab)
        if (select) {
            tab.lastUsed = SystemClock.elapsedRealtime()
            activeTabId = tab.id
            enforceSessionBudget()
        }
        return tab
    }

    fun selectTab(tab: Tab) {
        if (ghostModeEnabled) return
        tab.lastUsed = SystemClock.elapsedRealtime()
        activeTabId = tab.id
        enforceSessionBudget()
    }

    /**
     * Живых GeckoSession ограничено: каждая держит процессы/память страницы. Активная вкладка и
     * несколько последних остаются живыми (переключение мгновенное, без перезагрузки); самые
     * давние освобождаются, но их [Tab.sessionState] сохраняется, и при возврате страница
     * восстанавливается из него. В режиме призрака вытеснения нет.
     */
    fun enforceSessionBudget(maxLive: Int = MAX_LIVE_SESSIONS) {
        if (ghostModeEnabled) return
        tabs.filter { it.id != activeTabId && it.webView != null }
            .sortedByDescending { it.lastUsed }
            .drop((maxLive - 1).coerceAtLeast(0))
            .forEach { it.webView?.release() }
    }

    /** При нехватке памяти оставляем живой только видимую вкладку. */
    fun trimSessions() = enforceSessionBudget(1)

    fun closeTab(tab: Tab) {
        if (ghostModeEnabled) return
        tab.webView?.release()
        val index = tabs.indexOf(tab)
        if (index < 0) return
        if (tab.url != null) {
            closedTabs.add(tab.snapshot())
            if (closedTabs.size > 10) closedTabs.removeAt(0)
        }
        tabs.removeAt(index)
        if (tabs.isEmpty()) {
            newTab()
        } else if (tab.id == activeTabId) {
            activeTabId = tabs[index.coerceAtMost(tabs.lastIndex)].id
        }
    }

    fun restoreClosedTab() {
        if (ghostModeEnabled || closedTabs.isEmpty()) return
        val snap = closedTabs.removeAt(closedTabs.lastIndex)
        newTab(snap.url)
    }

    fun closeToStart(tab: Tab) {
        tab.webView?.release()
        tab.resetToStart()
    }

    // ---- Навигация ----

    fun submit(raw: String) {
        val tab = activeTab ?: newTab()
        when (val r = UrlResolver.resolve(raw, engine)) {
            is UrlResolver.Resolved.Open -> tab.load(r.url)
            is UrlResolver.Resolved.Rejected -> message = r.reason
            UrlResolver.Resolved.Empty -> Unit
        }
    }

    /** External links stay in the current tab during Ghost Mode. */
    fun openExternal(url: String) {
        val r = UrlResolver.resolve(url, engine)
        if (r is UrlResolver.Resolved.Open && !r.isSearch) {
            if (ghostModeEnabled) activeTab?.load(r.url) else newTab(r.url)
        }
    }

    override fun onCleared() {
        tabs.forEach { it.webView?.release() }
        super.onCleared()
    }

    fun persist() {
        if (ghostModeEnabled) return
        val list = tabs.map { it.snapshot() }
        val activeIndex = tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0)
        tabStore.save(list, activeIndex)
    }
}
