package app.swaga.browser.history

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(val title: String, val url: String)

class BookmarkStore(private val prefs: SharedPreferences) {
    fun load(): List<Bookmark> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val url = item.optString("u").takeIf { it.startsWith("https://") || it.startsWith("http://") }
                    ?: return@mapNotNull null
                Bookmark(item.optString("t").ifBlank { url }, url)
            }
        }.getOrDefault(emptyList())
    }

    fun save(items: List<Bookmark>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().put("t", item.title).put("u", item.url))
        }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private companion object { const val KEY = "bookmarks_json" }
}
