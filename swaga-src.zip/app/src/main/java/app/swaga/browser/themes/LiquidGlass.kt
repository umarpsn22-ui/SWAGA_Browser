package app.swaga.browser.themes

import android.content.Context
import android.os.Build
import android.view.WindowManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/*
 * Liquid Glass for #SwagaBrowser.
 *
 * What is real here and what is not:
 *  - REAL: compositor "blur behind" for dialogs and bottom sheets on Android 12+ (see
 *    [GlassWindowBlur]) – the page behind a sheet is genuinely blurred by the system.
 *  - REAL: layered glass surfaces drawn once per size (tint, specular sheen, caustic glow,
 *    inner light, chromatic rim) and a slow aurora backdrop that gives the glass something to sit on.
 *  - NOT physically correct: there is no refraction/lensing and no per-panel backdrop blur over the
 *    live Gecko page (GeckoView renders into its own surface; Compose cannot sample it).
 *    The bars over a web page are therefore a high-quality imitation, not real refraction.
 */

/** Colour stops of the aurora, derived from the theme accent. */
private val AuroraTeal = Color(0xFF3DD6C8)
private val AuroraViolet = Color(0xFF8B5CFF)
private val AuroraRose = Color(0xFFFF7AB6)

/**
 * Soft drifting colour field that sits behind glass panels. Without it a translucent panel over a flat
 * dark background is indistinguishable from a plain rectangle. Animation state is read only in the draw
 * phase, so it never triggers recomposition. When [animated] is false (a web page is open, or the
 * material is matte) the field is static and costs nothing per frame.
 */
@Composable
fun Modifier.liquidBackdrop(animated: Boolean = true): Modifier {
    val c = LocalSwaga.current
    val moving = animated && c.glass
    val phase: Float by if (moving) {
        rememberInfiniteTransition(label = "liquid-backdrop").animateFloat(
            initialValue = 0f,
            targetValue = (2.0 * Math.PI).toFloat(),
            animationSpec = infiniteRepeatable(tween(36_000, easing = LinearEasing), RepeatMode.Restart),
            label = "liquid-phase",
        )
    } else {
        remember { mutableStateOf(0.6f) }
    }
    val strength = if (c.isDark) 0.40f else 0.46f
    return this.drawBehind {
        drawRect(c.bg)
        val w = size.width
        val h = size.height
        val r = max(w, h)
        val p = phase
        fun blob(color: Color, cx: Float, cy: Float, radius: Float, a: Float) {
            drawRect(
                Brush.radialGradient(
                    colors = listOf(color.copy(alpha = a), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = radius,
                ),
            )
        }
        blob(c.accent, w * (0.18f + 0.10f * sin(p)), h * (0.14f + 0.05f * cos(p)), r * 0.72f, strength)
        blob(AuroraTeal, w * (0.88f + 0.06f * cos(p + 1.3f)), h * (0.40f + 0.06f * sin(p + 0.7f)), r * 0.62f, strength * 0.78f)
        blob(AuroraViolet, w * (0.28f + 0.10f * cos(p + 2.1f)), h * (0.86f + 0.04f * sin(p + 2.4f)), r * 0.70f, strength * 0.85f)
        blob(AuroraRose, w * (0.82f + 0.05f * sin(p + 4.0f)), h * 0.96f, r * 0.45f, strength * 0.38f)
        // slight vignette to anchor the edges
        drawRect(
            Brush.verticalGradient(
                listOf(
                    Color.Black.copy(alpha = if (c.isDark) 0.18f else 0f),
                    Color.Transparent,
                    Color.Black.copy(alpha = if (c.isDark) 0.22f else 0.03f),
                ),
            ),
        )
    }
}

/** Full-size backdrop as a standalone element (used by overlays such as the tab switcher). */
@Composable
fun LiquidBackdrop(modifier: Modifier = Modifier, animated: Boolean = true) {
    Box(modifier.fillMaxSize().liquidBackdrop(animated))
}

/**
 * Liquid-glass surface. All gradients/outlines are built in [drawWithCache], i.e. once per size change,
 * and replayed on draw – no per-frame allocations.
 *
 * Layers (bottom to top): ambient shadow outside the shape, frosted body tint, top specular sheen,
 * bottom caustic glow in the accent colour, corner highlight, inner light edge, chromatic rim.
 *
 * @param frost 1f = default translucency, >1f makes the body denser (use over busy content such as
 *   a web page or when the system cannot blur behind the window).
 */
@Composable
fun Modifier.liquidGlass(
    shape: Shape,
    elevated: Boolean = false,
    frost: Float = 1f,
): Modifier {
    val c = LocalSwaga.current
    val dark = c.isDark
    val base = if (elevated) c.surfaceHigh else c.surface
    val accent = c.accent
    val bg = c.bg
    val glass = c.glass
    return this.drawWithCache {
        val w = size.width
        val h = size.height
        val outline = shape.createOutline(size, layoutDirection, this)
        val px = density
        val rimWidth = 1.2f * px
        fun a(v: Float) = (v * frost).coerceIn(0f, 0.97f)

        val shadowSteps = if (elevated) 4 else 3
        val shadowColor = Color.Black
        val shadowBase = if (dark) 0.16f else 0.07f

        val body: Brush
        val sheen: Brush?
        val caustic: Brush?
        val corner: Brush?
        val rim: Brush
        val rimFringeA: Brush?
        val rimFringeB: Brush?
        if (glass) {
            body = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = if (dark) a(0.17f) else a(0.62f)),
                    base.copy(alpha = if (dark) a(0.50f) else a(0.66f)),
                    Color.White.copy(alpha = if (dark) a(0.07f) else a(0.34f)).mixWith(accent, 0.10f),
                    bg.copy(alpha = if (dark) a(0.46f) else a(0.52f)),
                ),
                start = Offset(0f, 0f),
                end = Offset(w, h),
            )
            sheen = Brush.verticalGradient(
                colors = listOf(Color.White.copy(alpha = if (dark) 0.26f else 0.60f), Color.Transparent),
                startY = 0f,
                endY = h * 0.52f,
            )
            caustic = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = if (dark) 0.30f else 0.22f), Color.Transparent),
                center = Offset(w * 0.86f, h * 1.08f),
                radius = max(w * 0.62f, h * 1.1f),
            )
            corner = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = if (dark) 0.34f else 0.70f), Color.Transparent),
                center = Offset(w * 0.12f, 0f),
                radius = max(h * 1.4f, w * 0.30f),
            )
            rim = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = if (dark) 0.78f else 0.95f),
                    Color.White.copy(alpha = if (dark) 0.10f else 0.40f),
                    accent.copy(alpha = 0.38f),
                    Color.White.copy(alpha = if (dark) 0.46f else 0.70f),
                ),
                start = Offset(0f, 0f),
                end = Offset(w, h),
            )
            rimFringeA = Brush.linearGradient(
                colors = listOf(AuroraTeal.copy(alpha = 0.40f), Color.Transparent),
                start = Offset(0f, 0f),
                end = Offset(w * 0.6f, h),
            )
            rimFringeB = Brush.linearGradient(
                colors = listOf(Color.Transparent, AuroraRose.copy(alpha = 0.36f)),
                start = Offset(w * 0.4f, 0f),
                end = Offset(w, h),
            )
        } else {
            body = Brush.linearGradient(
                colors = listOf(base, base.mixWith(c.surfaceHigh, 0.56f), base.mixWith(accent, 0.05f)),
                start = Offset(0f, 0f),
                end = Offset(w, h),
            )
            sheen = null
            caustic = null
            corner = null
            rim = Brush.linearGradient(
                colors = listOf(c.outline.copy(alpha = 0.9f), c.outline.copy(alpha = 0.55f)),
                start = Offset(0f, 0f),
                end = Offset(w, h),
            )
            rimFringeA = null
            rimFringeB = null
        }

        onDrawBehind {
            // ambient shadow: soft rings that fade outwards (kept outside so it does not muddy the glass)
            for (i in 1..shadowSteps) {
                val t = i / shadowSteps.toFloat()
                drawOutline(
                    outline = outline,
                    color = shadowColor.copy(alpha = shadowBase * (1f - t) * 0.55f),
                    style = Stroke(width = (2f + 5f * i) * px * (if (elevated) 1.15f else 0.85f)),
                )
            }
            drawOutline(outline, body)
            if (sheen != null) drawOutline(outline, sheen)
            if (caustic != null) drawOutline(outline, caustic)
            if (corner != null) drawOutline(outline, corner)
            if (rimFringeA != null && rimFringeB != null) {
                translate(left = -0.7f * px, top = -0.7f * px) {
                    drawOutline(outline, rimFringeA, style = Stroke(width = rimWidth))
                }
                translate(left = 0.7f * px, top = 0.7f * px) {
                    drawOutline(outline, rimFringeB, style = Stroke(width = rimWidth))
                }
                // inner light edge
                drawOutline(outline, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.Transparent)), style = Stroke(width = 3f * px))
            }
            drawOutline(outline, rim, style = Stroke(width = rimWidth))
        }
    }
}

private fun Color.mixWith(other: Color, amount: Float): Color {
    val t = amount.coerceIn(0f, 1f)
    return Color(
        red = red + (other.red - red) * t,
        green = green + (other.green - green) * t,
        blue = blue + (other.blue - blue) * t,
        alpha = alpha,
    )
}

/**
 * Glass control with a springy press: the whole glass layer scales down slightly and recovers with a
 * small overshoot, like a liquid droplet being pushed.
 */
@Composable
fun Modifier.glassButton(
    shape: Shape,
    elevated: Boolean = false,
    onClick: () -> Unit,
): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.955f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 520f),
        label = "glass-press",
    )
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .liquidGlass(shape, elevated)
        .clickable(interactionSource = source, indication = null, onClick = onClick)
}

/**
 * Asks the system compositor to blur whatever is behind the current dialog / bottom-sheet / alert
 * window (Android 12+, when the device allows cross-window blur). This is the one place where the page
 * behind the UI – including the Gecko surface – is truly blurred. On older Android versions, or when the
 * system disables blur (battery saver, low-end devices), nothing changes and the regular scrim is used.
 */
@Composable
fun GlassWindowBlur(radius: Dp = 26.dp) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
    val view = LocalView.current
    val px = with(LocalDensity.current) { radius.roundToPx() }
    DisposableEffect(view, px) {
        val apply = Runnable {
            val root = view.rootView
            val params = root.layoutParams as? WindowManager.LayoutParams
            val wm = view.context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            if (params != null && wm != null && root.isAttachedToWindow) {
                params.flags = params.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                params.blurBehindRadius = px
                try {
                    wm.updateViewLayout(root, params)
                } catch (_: RuntimeException) {
                    // Window is not updatable on this device; the scrim stays as the fallback.
                }
            }
        }
        view.post(apply)
        onDispose { view.removeCallbacks(apply) }
    }
}

/** Convenience: soft diagonal accent wash for small icon tiles (used by start page letters). */
fun glassTileBrush(c: SwagaColors, size: Size): Brush = Brush.linearGradient(
    colors = listOf(
        Color.White.copy(alpha = if (c.isDark) 0.20f else 0.82f),
        c.surfaceHigh.copy(alpha = 0.90f),
        c.accent.copy(alpha = 0.34f),
    ),
    start = Offset(0f, 0f),
    end = Offset(size.width, size.height),
)
