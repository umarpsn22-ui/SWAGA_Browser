package app.swaga.browser.history

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Local-only visit history. Ghost Mode never calls add(). */
data class HistoryEntry(val title: String, val url: String, val visitedAt: Long)

class HistoryStore(private val prefs: SharedPreferences) {
    fun load(): List<HistoryEntry> = runCatching {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { index ->
            val row = array.optJSONObject(index) ?: return@mapNotNull null
            val url = row.optString("u")
            if (!url.startsWith("https://") && !url.startsWith("http://")) return@mapNotNull null
            HistoryEntry(row.optString("t").ifBlank { url }, url, row.optLong("at"))
        }
    }.getOrDefault(emptyList())

    fun add(current: List<HistoryEntry>, title: String, url: String): List<HistoryEntry> {
        if (!url.startsWith("https://") && !url.startsWith("http://")) return current
        val next = (listOf(HistoryEntry(title.ifBlank { url }, url, System.currentTimeMillis())) +
            current.filterNot { it.url == url }).take(MAX)
        save(next)
        return next
    }

    fun remove(entry: HistoryEntry) = save(load().filterNot { it.url == entry.url && it.visitedAt == entry.visitedAt })
    fun clear() = prefs.edit().remove(KEY).apply()

    private fun save(items: List<HistoryEntry>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject().put("t", it.title).put("u", it.url).put("at", it.visitedAt)) }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private companion object {
        const val KEY = "history_json"
        const val MAX = 500
    }
}
